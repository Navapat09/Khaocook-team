import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      {/* ส่วนหัว */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image source={require('./assets/setting.png')} style={styles.headerIcon} />
        </View>
        <Text style={styles.headerTitle}>Account</Text>
        <View style={styles.headerRight}>
          <Image source={require('./assets/notification.png')} style={styles.headerIcon} />
        </View>
      </View>

      {/* ส่วนโปรไฟล์ */}
      <View style={styles.profileContainer}>
        <View style={styles.profileButton}>
          <Text style={styles.profileButtonText}>เชฟฝึกหัด</Text>
        </View>
        <Image source={require('./assets/tomato.png')} style={styles.profileImage} />
        <Text style={styles.profileName}>น้อง มะเขือ</Text>
        <Text style={styles.profileDescription}>พึ่งเริ่มหัดทำอาหารค่ะ</Text>
        <View style={styles.statsContainer}>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>500</Text>
            <Text style={styles.statsLabel}>Followers</Text>
          </View>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>200</Text>
            <Text style={styles.statsLabel}>Follower</Text>
          </View>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>1,000</Text>
            <Text style={styles.statsLabel}>Like</Text>
          </View>
        </View>
      </View>

      {/* ส่วนโพสต์ */}
      <ScrollView style={styles.postContainer}>
        <View style={styles.postItem}>
          <View style={styles.postContent}>
            <Text style={styles.postTitle}>ข้าวผัดกุ้ง</Text>
            <Text style={styles.postDescription}>ข้าวผัดกุ้งสำหรับข้าวผัดเลิฟเวอร์ อออ</Text>
            <View style={styles.postAuthor}>
              <Image source={require('./assets/tomato.png')} style={styles.postAuthorImage} />
              <Text style={styles.postAuthorName}>น้องมะเขือ</Text>
            </View>
          </View>
          <Image source={require('./assets/friedrice.png')} style={styles.postImage} />
        </View>

        <View style={styles.postItem}>
          <View style={styles.postContent}>
            <Text style={styles.postTitle}>กุ้งดองแซลมอนดอง</Text>
            <Text style={styles.postDescription}>ของดีมากค่ะ จะมาแนะนำสูตรป่าตอง</Text>
          </View>
          <Image source={require('./assets/shrimpsalmon.png')} style={styles.postImage} />
        </View>
      </ScrollView>

      {/* ส่วนแถบนำทางด้านล่าง */}
      <View style={styles.bottomNav}>
        <View style={styles.navItem}>
          <Image source={require('./assets/search.png')} style={styles.navIcon} />
          <Text style={styles.navLabel}>ค้นหา</Text>
        </View>
        <View style={styles.navItem}>
          <Image source={require('./assets/save.png')} style={styles.navIcon} />
          <Text style={styles.navLabel}>เก็บสูตร</Text>
        </View>
        <View style={styles.navItem}>
          <Image source={require('./assets/random.png')} style={styles.navIcon} />
          <Text style={styles.navLabel}>สุ่มเมนู</Text>
        </View>
        <View style={styles.navItem}>
          <Image source={require('./assets/alert.png')} style={styles.navIcon} />
          <Text style={styles.navLabel}>แจ้งเตือน</Text>
        </View>
        <View style={styles.navItem}>
          <Image source={require('./assets/profile.png')} style={styles.navIcon} />
          <Text style={styles.navLabel}>โปรไฟล์</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerLeft: {
    width: 30,
    height: 30,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  headerRight: {
    width: 30,
    height: 30,
  },
  headerIcon: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  profileContainer: {
    alignItems: 'center',
    padding: 20,
  },
  profileButton: {
    backgroundColor: '#c8e6c9',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
    marginBottom: 10,
  },
  profileButtonText: {
    color: '#2e7d32',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 10,
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  profileDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
  },
  statsItem: {
    alignItems: 'center',
  },
  statsNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  statsLabel: {
    fontSize: 14,
    color: '#666',
  },
  postContainer: {
    flex: 1,
  },
  postItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  postImage: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginLeft: 16,
  },
  postContent: {
    flex: 1,
  },
  postTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  postAuthor: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  postAuthorImage: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 5,
  },
  postAuthorName: {
    fontSize: 14,
    color: '#666',
  },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  navItem: {
    alignItems: 'center',
  },
  navIcon: {
    width: 24,
    height: 24,
    resizeMode: 'contain',
  },
  navLabel: {
    fontSize: 12,
    color: '#666',
  },
});

export default App;