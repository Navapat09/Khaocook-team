import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      {/* ส่วนหัว */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image source={require('./assets/setting.png')} style={styles.headerIcon} />
        </View>
        <Text style={styles.headerTitle}>Account</Text>
        <View style={styles.headerRight}>
          <Image source={require('./assets/notification.png')} style={styles.headerIcon} />
        </View>
      </View>

      {/* ส่วนโปรไฟล์ */}
      <View style={styles.profileContainer}>
        <Image source={require('./assets/cat.png')} style={styles.profileImage} />
        <Text style={styles.profileName}>เชฟ แมว</Text>
        <Text style={styles.profileDescription}>ทำงานหนักเพื่อกินเนื้อ</Text>
        <View style={styles.followButton}>
          <Text style={styles.followButtonText}>Follow</Text>
        </View>
        <View style={styles.statsContainer}>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>40</Text>
            <Text style={styles.statsLabel}>Post</Text>
          </View>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>2,500</Text>
            <Text style={styles.statsLabel}>Followers</Text>
          </View>
          <View style={styles.statsItem}>
            <Text style={styles.statsNumber}>6,000</Text>
            <Text style={styles.statsLabel}>Like</Text>
          </View>
        </View>
      </View>

      {/* ส่วนโพสต์ */}
      <ScrollView style={styles.postContainer}>
        <View style={styles.postItem}>
          <Image source={require('./assets/salmon.png')} style={styles.postImage} />
          <View style={styles.postContent}>
            <Text style={styles.postTitle}>สเต็กแซลมอน</Text>
            <Text style={styles.postDescription}>แซลมอนเนื้อนุ่มละมุนลิ้น ผมนี่อยากทำอะไรอร่อยๆ ก็ทำนะ</Text>
            <View style={styles.postAuthor}>
              <Image source={require('./assets/cat.png')} style={styles.postAuthorImage} />
              <Text style={styles.postAuthorName}>เชฟแมว</Text>
            </View>
          </View>
        </View>

        <View style={styles.postItem}>
          <Image source={require('./assets/fish.png')} style={styles.postImage} />
          <View style={styles.postContent}>
            <Text style={styles.postTitle}>ปลาทับทิมสามรส</Text>
            <Text style={styles.postDescription}>เมนูที่เหมาะกับทุกคนในครอบครัว</Text>
            <View style={styles.postAuthor}>
              <Image source={require('./assets/cat.png')} style={styles.postAuthorImage} />
              <Text style={styles.postAuthorName}>เชฟแมว</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  headerLeft: {
    width: 30,
    height: 30,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  headerRight: {
    width: 30,
    height: 30,
  },
  headerIcon: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  profileContainer: {
    alignItems: 'center',
    padding: 20,
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 10,
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  profileDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  followButton: {
    backgroundColor: '#ff9800',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginBottom: 10,
  },
  followButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 20,
  },
  statsItem: {
    alignItems: 'center',
  },
  statsNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  statsLabel: {
    fontSize: 14,
    color: '#666',
  },
  postContainer: {
    flex: 1,
  },
  postItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  postImage: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginRight: 16,
  },
  postContent: {
    flex: 1,
  },
  postTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  postDescription: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  postAuthor: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  postAuthorImage: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginRight: 5,
  },
  postAuthorName: {
    fontSize: 14,
    color: '#666',
  },
});

export default App;