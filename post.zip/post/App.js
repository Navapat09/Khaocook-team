import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, Image } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      {/* ส่วนหัว */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
      </View>

      {/* ส่วนเนื้อหา */}
      <ScrollView style={styles.content}>
        <View style={styles.inputContainer}>
          <Text style={styles.label}>ชื่อเมนู :</Text>
          <TextInput style={styles.input} placeholder="เขียนชื่อเมนูที่คุณต้องการแนะนำ" />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>ค่าอธิบาย :</Text>
          <TextInput style={styles.input} placeholder="เขียนอธิบายเมนูของคุณ" />
        </View>

        <TouchableOpacity style={styles.imagePicker}>
          <Image source={require('./assets/image_placeholder.png')} style={styles.imagePlaceholder} />
          <Text style={styles.imagePickerText}>เพิ่มรูปหน้าปก</Text>
        </TouchableOpacity>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>ส่วนผสม</Text>
          <TextInput style={styles.input} placeholder="เขียนส่วนผสมของคุณ" multiline />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>วิธีการทำ</Text>
          <TextInput style={styles.input} placeholder="เขียนวิธีการทำของคุณ" multiline />
        </View>

        <TouchableOpacity style={styles.addImageButton}>
          <Text style={styles.addImageButtonText}>รูปภาพเพิ่มเติม</Text>
          <Text style={styles.addImageButtonIcon}>+</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* ส่วนแถบนำทางด้านล่าง */}
      <View style={styles.bottomNav}>
        <View style={styles.postButtonContainer}>
          <TouchableOpacity style={styles.postButton}>
            <Text style={styles.postButtonText}>โพสต์ ↑</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.navItems}>
          <TouchableOpacity style={styles.navItem}>
            <Image source={require('./assets/search.png')} style={styles.navIcon} />
            <Text style={styles.navLabel}>ค้นหา</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem}>
            <Image source={require('./assets/save.png')} style={styles.navIcon} />
            <Text style={styles.navLabel}>เก็บสูตร</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem}>
            <Image source={require('./assets/random.png')} style={styles.navIcon} />
            <Text style={styles.navLabel}>สุ่มเมนู</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem}>
            <Image source={require('./assets/alert.png')} style={styles.navIcon} />
            <Text style={styles.navLabel}>แจ้งเตือน</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navItem}>
            <Image source={require('./assets/profile.png')} style={styles.navIcon} />
            <Text style={styles.navLabel}>โปรไฟล์</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    paddingRight: 10,
  },
  backButtonText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  imagePicker: {
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 20,
    alignItems: 'center',
    marginBottom: 16,
    backgroundColor: '#f0f0f0',
  },
  imagePlaceholder: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
    marginBottom: 8,
  },
  imagePickerText: {
    fontSize: 16,
    color: '#666',
  },
  addImageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#f0f0f0',
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  addImageButtonText: {
    fontSize: 16,
    marginRight: 8,
  },
  addImageButtonIcon: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  bottomNav: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  postButtonContainer: {
    alignItems: 'center',
    marginBottom: 8, // เพิ่ม margin bottom
  },
  postButton: {
    backgroundColor: '#ffe0b2',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  postButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ff9800',
    marginRight: 5,
  },
  navItems: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  navItem: {
    alignItems: 'center',
  },
  navIcon: {
    width: 24,
    height: 24,
    resizeMode: 'contain',
  },
  navLabel: {
    fontSize: 12,
    color: '#666',
  },
});

export default App;